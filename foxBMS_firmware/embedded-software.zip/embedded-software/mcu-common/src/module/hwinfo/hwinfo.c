/**
 *
 * @copyright &copy; 2010 - 2021, Fraunhofer-Gesellschaft zur Foerderung der
 *  angewandten Forschung e.V. All rights reserved.
 *
 * BSD 3-Clause License
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1.  Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 * 3.  Neither the name of the copyright holder nor the names of its
 *     contributors may be used to endorse or promote products derived from
 *     this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * We kindly request you to use one or more of the following phrases to refer
 * to foxBMS in your hardware, software, documentation or advertising
 * materials:
 *
 * &Prime;This product uses parts of foxBMS&reg;&Prime;
 *
 * &Prime;This product includes parts of foxBMS&reg;&Prime;
 *
 * &Prime;This product is derived from foxBMS&reg;&Prime;
 *
 */

/**
 * @file    hwinfo.c
 * @author  foxBMS Team
 * @date    12.09.2018 (date of creation)
 * @ingroup HardwareInfo
 * @prefix  HW
 *
 * @brief   hardware info
 *
 */

/*================== Includes ===============================================*/
#include "hwinfo.h"

#include "adc.h"
#include "database.h"
#include "diag.h"

/*================== Macros and Definitions =================================*/

/*================== Static Constant and Variable Definitions ===============*/
static DATA_BLOCK_HW_INFO_s hw_tab = {
    .vbat_mV = 0,
    .temperature = 0.0,
    .state_vbat = 0,
    .state_temperature = 0,
};

/*================== Extern Constant and Variable Definitions ===============*/
#define HW_MCU_MINIMUM_DIE_TEMP_DEG_CELSIUS             (-40)
#define HW_MCU_MAXIMUM_DIE_TEMP_DEG_CELSIUS             (125)
#define HW_WARN_LOW_COIN_CELL_THRESHOLD_mV             (2500)
#define HW_ERROR_LOW_COIN_CELL_THRESHOLD_mV            (2200)

/*================== Static Function Prototypes =============================*/

/*================== Static Function Implementations ========================*/

/*================== Extern Function Implementations ========================*/
void HW_update(void) {
    /* Get MCU temperature */
    hw_tab.temperature = ADC_GetMCUTemp_C();
    hw_tab.state_temperature++;

    /* Check if MCU die temperature is inside operating range */
    STD_RETURN_TYPE_e result = E_NOT_OK;
    if (hw_tab.temperature < HW_MCU_MAXIMUM_DIE_TEMP_DEG_CELSIUS &&
            hw_tab.temperature > HW_MCU_MINIMUM_DIE_TEMP_DEG_CELSIUS) {
        result = E_OK;
    }
    DIAG_checkEvent(result, DIAG_CH_ERROR_MCU_DIE_TEMPERATURE, 0);

    /* Get coin cell voltage */
    hw_tab.vbat_mV = ADC_GetVBAT_mV();
    hw_tab.state_vbat++;

    /* Check if MCU coin cell voltage is low and coin cell should be replaced */
    result = E_NOT_OK;
    /* check for coin cell voltage low */
    if (hw_tab.vbat_mV > HW_WARN_LOW_COIN_CELL_THRESHOLD_mV) {
        result = E_OK;
    }
    DIAG_checkEvent(result, DIAG_CH_LOW_COIN_CELL_VOLTAGE, 0);
    result = E_NOT_OK;
    /* check for  coin cell voltage critically low */
    if (hw_tab.vbat_mV > HW_ERROR_LOW_COIN_CELL_THRESHOLD_mV) {
        result = E_OK;
    }
    DIAG_checkEvent(result, DIAG_CH_CRIT_LOW_COIN_CELL_VOLTAGE, 0);

    /* Write data to database */
    DB_WriteBlock(&hw_tab, DATA_BLOCK_ID_HW_INFO);
}
